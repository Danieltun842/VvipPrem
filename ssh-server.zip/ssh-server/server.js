const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const { NodeSSH } = require('node-ssh');
const ssh = new NodeSSH();
const cors = require('cors');
const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(cors());

app.post('/create-ssh', async (req, res) => {
    const { username, password, expirationDays } = req.body;
    const expirationDate = new Date();
    expirationDate.setDate(expirationDate.getDate() + parseInt(expirationDays));

    console.log('Received request to create SSH account for:', username);

    try {
        await ssh.connect({
            host: '152.42.251.58',
            username: 'root',
            password: 'W{^jlYPqmcnG'
        });
        console.log('Connected to VPS');

        const expirationDateStr = expirationDate.toISOString().split('T')[0];
        const ipLimit = 2; // Batas IP otomatis 2
        const userAddCommand = `sudo useradd -m -e ${expirationDateStr} ${username} -p $(openssl passwd -1 ${password})`;
        const ipLimitCommand = `echo "${ipLimit}" > /etc/klmpk/limit/ssh/ip/${username}`;
        const atCommand = `echo "sudo userdel -r ${username} && sudo sed -i '/### ${username} /d' /etc/.ssh.db && sudo rm -f /etc/klmpk/limit/ssh/ip/${username}" | at now + 60 minutes`;
        const fullCommand = `${userAddCommand} && ${ipLimitCommand} && ${atCommand}`;

        console.log('Executing command:', fullCommand);

        const result = await ssh.execCommand(fullCommand);

        const isWarning = result.stderr && result.stderr.includes('warning: commands will be executed using /bin/sh');

        if (result.stderr && !isWarning) {
            console.error('STDERR:', result.stderr);
            res.status(500).json({ success: false, message: 'Failed to create SSH account', error: result.stderr });
        } else {
            console.log('STDOUT:', result.stdout);
            res.json({ 
                success: true, 
                message: 'SSH account created successfully', 
                username: username,
                expirationDate: expirationDateStr,
                domain: 'your-domain.com' // ganti dengan domain yang sebenarnya jika diperlukan
            });
        }
    } catch (err) {
        console.error('Failed to connect to VPS or execute command:', err);
        res.status(500).json({ success: false, message: 'Failed to create SSH account', error: err.message });
    }
});

app.post('/create-vmess', async (req, res) => {
    const { username, expirationDays } = req.body;
    const expirationDate = new Date();
    expirationDate.setDate(expirationDate.getDate() + parseInt(expirationDays));

    console.log('Received request to create VMess account for:', username);

    try {
        await ssh.connect({
            host: '152.42.251.58',
            username: 'root',
            password: 'W{^jlYPqmcnG'
        });
        console.log('Connected to VPS');

        const uuid = require('crypto').randomBytes(16).toString('hex');
        const command = `
            addxrayusr vmess ${username} ${expirationDate.toISOString().split('T')[0]} ${uuid}
            systemctl restart xray
        `;
        console.log('Executing command:', command);

        const result = await ssh.execCommand(command);
        
        if (result.stderr) {
            console.error('STDERR:', result.stderr);
            res.status(500).json({ success: false, message: 'Failed to create VMess account', error: result.stderr });
        } else {
            console.log('STDOUT:', result.stdout);
            
            const vmess_json1 = {
                v: "2",
                ps: username,
                add: 'kesyy.klmpk.systems',
                port: "443",
                id: uuid,
                aid: "0",
                net: "ws",
                type: "none",
                host: "",
                path: "/vmess",
                tls: "tls"
            };

            const vmess_json2 = {
                v: "2",
                ps: username,
                add: 'kesyy.klmpk.systems',
                port: "80",
                id: uuid,
                aid: "0",
                net: "ws",
                type: "none",
                path: "/vmess",
                tls: "none"
            };

            const vmess_json3 = {
                v: "2",
                ps: username,
                add: 'kesyy.klmpk.systems',
                port: "443",
                id: uuid,
                aid: "0",
                net: "grpc",
                type: "none",
                host: "",
                path: "",
                tls: "tls"
            };

            const vmess_base641 = Buffer.from(JSON.stringify(vmess_json1)).toString('base64');
            const vmess_base642 = Buffer.from(JSON.stringify(vmess_json2)).toString('base64');
            const vmess_base643 = Buffer.from(JSON.stringify(vmess_json3)).toString('base64');

            const vmesslink1 = `vmess://${vmess_base641}`;
            const vmesslink2 = `vmess://${vmess_base642}`;
            const vmesslink3 = `vmess://${vmess_base643}`;

            res.json({
                success: true,
                message: 'VMess account created successfully',
                username: username,
                expirationDate: expirationDate.toISOString().split('T')[0],
                vmessLinks: {
                    linkTLS: vmesslink1,
                    linkNTLS: vmesslink2,
                    linkGRPC: vmesslink3
                }
            });
        }
    } catch (err) {
        console.error('Failed to connect to VPS or execute command:', err);
        res.status(500).json({ success: false, message: 'Failed to create VMess account', error: err.message });
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
